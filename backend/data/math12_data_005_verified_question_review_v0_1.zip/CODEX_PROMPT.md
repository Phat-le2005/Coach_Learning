Implement DATA-MATH12-005 batch 001 in Phat-le2005/Coach_Learning.

Use the supplied review batch exactly. Do not invent, rewrite, or expand academic content beyond the review files.

GOAL
Add an auditable review layer for DATA-MATH12-004 derivative candidates.

FILES
Copy:
backend/data/questions/math/grade12/derivative_applications_v0_1/review/batch_001/

REQUIREMENTS
1. Preserve the original staging candidate_questions.json raw data.
2. Apply candidate_patch.json deterministically to the matching candidate IDs only, or add an equivalent review overlay resolver.
3. VERIFIED means source/content/answer/taxonomy review passed, but does NOT make a question production-importable.
4. REJECTED candidates must never be promotable.
5. HOLD candidates remain REVIEW_REQUIRED and must never be promotable.
6. Do not alter any candidate not named in this batch.
7. Preserve source_code, subsource_code, page, question number, original fingerprint and raw text.
8. Respect the correction for M12_DERIV_CAND_0038: MULTIPLE_CHOICE, not SHORT_ANSWER.
9. Do not auto-promote the 12 VERIFIED records.
10. Do not create migrations.
11. Do not modify mastery, recommendation, digital twin, attempts, diagnostics, or curriculum canonical data.
12. Add validation/tests for review overlays:
   - all candidate IDs resolve;
   - VERIFIED candidates have reviewed content, answer and taxonomy review;
   - HOLD/REJECTED cannot promote;
   - patch does not touch unspecified candidates;
   - candidate 0038 becomes MULTIPLE_CHOICE in reviewed view;
   - current batch counts are exactly 12 VERIFIED / 2 HOLD / 2 REJECTED.
13. Keep TRUE_FALSE_GROUP behavior unchanged.

IMPORTANT QUALITY FLAGS
- M12_DERIV_CAND_0121 must remain HOLD_SOURCE_ANSWER_CONFLICT.
- M12_DERIV_CAND_0063 must remain HOLD_EXPERT_REVIEW.
- M12_DERIV_CAND_0152 and M12_DERIV_CAND_0172 must remain REJECTED.

After implementation run:
cd backend
pytest
python -m app.validate_curriculum_staging
python -m app.validate_question_staging

Report exact test counts and changed files. Do not claim pass unless actually run.
