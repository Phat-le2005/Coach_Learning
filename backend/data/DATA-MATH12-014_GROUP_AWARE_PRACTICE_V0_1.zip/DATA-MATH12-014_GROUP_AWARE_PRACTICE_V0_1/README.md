# DATA-MATH12-014 — Group-aware learning/practice path v0.1

Base commit: `483ff09112a1f694699b28704a48f8293040ed92`

This phase implements the runtime semantics for four-statement true/false groups.

## Core invariant

A `TRUE_FALSE_FOUR` is **one student-facing question**, never four independent practice
questions.

The group is scored once using the existing `MOET_2025_TRUE_FALSE` scorer:

| correct child statements | practice score |
| ---: | ---: |
| 0 | 0.00 |
| 1 | 0.10 |
| 2 | 0.25 |
| 3 | 0.50 |
| 4 | 1.00 |

At the same time, mastery receives **four child evidence events** because each statement has
its own reviewed ProblemType/Concept/LearningOutcome mappings.

There is no fifth mastery event for the aggregate group score.

## Persistence

Add `QuestionGroupAttempt` + `QuestionGroupAttemptItem`.

A group submission atomically creates:
- 1 parent group attempt;
- 4 normal child `QuestionAttempt` rows;
- 4 parent/child link rows;
- 4 calls to the existing mastery evidence publisher.

If any child evaluation/evidence projection fails, the entire transaction rolls back.

## Child isolation

Every automated standalone selector must exclude any Question present in
`question_group_items`.

This includes practice, recommendation, priorities, diagnostics, repair, exams, learning,
assignments, and synthetic-student selection. Staff Question Bank CRUD may still inspect
children.

This rule prevents the future 152 imported child rows from ever appearing to students as
152 independent questions.

## Current derivative data

The trusted derivative import remains DRAFT-only, so this phase does not publish the 38
groups. Tests should use synthetic APPROVED groups to verify runtime behavior.

The upstream data invariants remain:
- academic review: 67/67;
- canonical snapshot: 38 groups / 152 children;
- visual registry: 8 ready / 1 missing;
- production release eligible: 0.

## Not part of this phase

Teacher assignment evidence integration remains intentionally deferred.
No rights clearance or visual asset serving is added.
