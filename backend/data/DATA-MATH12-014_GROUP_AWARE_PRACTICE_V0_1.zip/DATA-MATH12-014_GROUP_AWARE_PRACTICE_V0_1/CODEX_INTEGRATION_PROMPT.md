# CODEX INTEGRATION PROMPT — DATA-MATH12-014

Integrate on exact base commit:

`483ff09112a1f694699b28704a48f8293040ed92`

Goal: make `TRUE_FALSE_FOUR` a first-class **group-aware practice item** while preserving
child-level mastery evidence and preventing grouped children from leaking into any
standalone Question selector.

Do not access external sources. Do not approve or publish the derivative dataset.

## 1. Add contract data

Copy the attached contract files under a suitable non-runtime documentation/data path, e.g.

`backend/data/questions/math/grade12/derivative_applications_v0_1/production_bridge/v0_1/`

Add:
- `group_practice_contract.json`
- `group_practice_storage_contract.json`
- `standalone_child_isolation_policy.json`
- `group_practice_api_contract.json`

Update the bridge README only as needed.

## 2. Migration 0031

Add:

`backend/migrations/versions/0031_question_group_practice.py`

with:

revision = `0031_question_group_practice`
down_revision = `0030_question_groups`

Create `question_group_attempts`:
- id UUID PK
- practice_session_id UUID NOT NULL
- student_id UUID NOT NULL
- question_group_id UUID NOT NULL
- correct_count integer NOT NULL, CHECK 0..4
- score float NOT NULL, CHECK 0..1
- response_time_seconds float NULL, CHECK > 0
- scoring_policy using the existing QuestionGroupScoringPolicy enum/value semantics
- created_at timestamptz server default now
- composite FK `(practice_session_id, student_id)` to
  `practice_sessions(id, student_id)` ON DELETE CASCADE
- FK question_group_id -> question_groups.id ON DELETE RESTRICT
- UNIQUE(practice_session_id, question_group_id)
- useful indexes for session/student/group lookup.

Create `question_group_attempt_items`:
- id UUID PK
- question_group_attempt_id UUID NOT NULL
- question_group_item_id UUID NOT NULL
- question_attempt_id UUID NOT NULL
- label varchar(1) NOT NULL
- order_index integer NOT NULL
- FK parent -> question_group_attempts ON DELETE CASCADE
- FK group item -> question_group_items ON DELETE RESTRICT
- FK question attempt -> question_attempts ON DELETE RESTRICT
- UNIQUE(parent,label)
- UNIQUE(parent,order_index)
- UNIQUE(question_attempt_id)
- labels exactly a,b,c,d
- order indexes 0..3.

Downgrade must cleanly remove only these new tables/indexes.

Update ORM exports/database model imports.

## 3. ORM models

Add `QuestionGroupAttempt` and `QuestionGroupAttemptItem` to `app/practice/models.py`.

Do **not** replace `QuestionAttempt`.
The four child rows remain ordinary `QuestionAttempt`s so the existing
`MasteryAttemptEvidencePublisher` stays authoritative.

Relationships should allow:
- PracticeSession -> group_attempts
- QuestionGroupAttempt -> four ordered attempt_items
- attempt_item -> QuestionGroupItem
- attempt_item -> QuestionAttempt.

## 4. Shared standalone-child isolation rule

Create one reusable helper, e.g.

`app/questions/eligibility.py`

with a SQLAlchemy predicate that means:

`Question.id NOT IN (SELECT question_group_items.question_id ...)`

(or equivalent `NOT EXISTS`).

Use the helper for **all automated/student-facing standalone Question selection**.

Audit and patch at least:
- `app/practice/service.py`
- `app/recommendations/question_service.py`
- `app/recommendations/priority_service.py`
- `app/diagnostics/selector.py`
- `app/diagnostics/blueprint.py`
- `app/repair/service.py`
- `app/exams/blueprint_service.py`
- `app/learning/service.py`
- `app/assignments/service.py`
- `app/synthetic_student_service.py`

Search the whole backend for other `QuestionStatus.APPROVED` candidate queries and patch
equivalent automated selectors too.

Do not hide children from staff/admin Question Bank CRUD/list/get; internal review must
still be possible.

### Critical invariant

Even in a test where:
- parent QuestionGroup = APPROVED
- all four child Question rows = APPROVED

no automated standalone selector may return any of those four child IDs.

The legacy practice `/answer` endpoint must reject a grouped child as
`QUESTION_NOT_ELIGIBLE`.

## 5. Group practice schemas

Add schemas such as:

- `PracticeQuestionGroupItemRead`
- `PracticeQuestionGroupRead`
- `PracticeItemRead`
- `PracticeGroupAnswerItem`
- `PracticeGroupAnswerCreate`
- `QuestionGroupAttemptItemRead`
- `QuestionGroupAttemptRead`

`PracticeGroupAnswerCreate` must require exactly four unique labels `a,b,c,d`.
Reject missing, duplicate, or unknown labels before DB writes.

Normalize/validate TRUE/FALSE answers with existing answer-evaluation semantics; do not
invent new scoring rules.

Before submission, the group read must expose content only, not child correct answers.

## 6. Group eligibility

Add deterministic group selection to PracticeService or a focused
QuestionGroupPracticeService.

An eligible group must:
- belong to the practice subject;
- group status APPROVED;
- group type TRUE_FALSE_FOUR;
- scoring policy MOET_2025_TRUE_FALSE;
- have exactly four items a,b,c,d / indexes 0..3;
- all child Questions status APPROVED;
- all children type TRUE_FALSE;
- each child have ProblemType, Concept and LearningOutcome classification;
- not already have a QuestionGroupAttempt in this practice session.

Scope:
- if practice has ProblemType targets, the group must contain at least one child mapped to
  one of those ProblemTypes;
- if practice has Concept targets, the group must contain at least one child mapped to one
  of those Concepts;
- apply both dimensions when both are non-empty.

Order deterministically by group creation/id or a clearly documented stable order.

Do not serve DRAFT derivative groups.

## 7. Unified next-item endpoint

Keep legacy:

`GET /practice/sessions/{id}/next-question`

for backward compatibility, but it must return standalone-only Questions.

Add:

`GET /practice/sessions/{id}/next-item`

Return:
- an eligible `QUESTION_GROUP` first when one remains;
- otherwise an eligible standalone `QUESTION`;
- 404 `NO_AVAILABLE_PRACTICE_ITEM` when neither remains.

Suggested response:

```json
{
  "item_type": "QUESTION_GROUP",
  "question": null,
  "question_group": { "...": "..." }
}
```

or the symmetric QUESTION form.

## 8. Atomic group submission

Add:

`POST /practice/sessions/{id}/group-answer`

Request:

```json
{
  "question_group_id": "...",
  "answers": [
    {"label":"a","student_answer":"TRUE"},
    {"label":"b","student_answer":"FALSE"},
    {"label":"c","student_answer":"TRUE"},
    {"label":"d","student_answer":"FALSE"}
  ],
  "response_time_seconds": 120.5
}
```

Inside one transaction:

1. lock the PracticeSession row;
2. authorize student ownership;
3. require ACTIVE;
4. reject duplicate parent group attempt;
5. re-resolve the group through the eligible-group query;
6. validate exact a,b,c,d shape;
7. evaluate each child using the existing `AnswerEvaluationService`;
8. require all four to auto-evaluate;
9. allocate four consecutive `QuestionAttempt.attempt_number`s in a,b,c,d order;
10. create four child QuestionAttempt rows:
    - TRUE_FALSE question ids;
    - canonical student answers;
    - child is_correct;
    - child score 1.0 or 0.0;
    - evaluation_status AUTO_EVALUATED;
    - response_time_seconds = null;
    - hint_count = 0;
11. compute `correct_count`;
12. call existing `score_question_group(
        MOET_2025_TRUE_FALSE,
        correctness,
        max_points=1.0
    )`;
13. create one QuestionGroupAttempt with aggregate score and the request's group-level
    response_time_seconds;
14. create four QuestionGroupAttemptItem rows linking group item -> child attempt;
15. publish exactly four `AttemptEvaluatedEvidence` events in a,b,c,d order through the
    existing evidence publisher;
16. never publish aggregate group score as a mastery event;
17. commit only after all four evidence publications succeed.

If any step fails, rollback:
- parent group attempt;
- all child QuestionAttempts;
- all link rows;
- all mastery/review projections in that transaction.

Duplicate/concurrent submission should map to a stable 409 error such as
`QUESTION_GROUP_ALREADY_ANSWERED`.

## 9. Mastery semantics

The four child evidence events are authoritative.

Verify with the real `MasteryAttemptEvidencePublisher` that the mapped
StudentConceptMastery / StudentProblemTypeMastery rows update from each child.

Do **not** mutate ConceptRelation or other static curriculum graph rows.

Do not apply the group aggregate score as additional mastery evidence.

This phase does not automatically invoke KnowledgeGapService; the updated mastery graph is
the input for that later orchestration.

## 10. Session completion

Existing standalone answer logic currently completes a session when no standalone Question
remains. That becomes incorrect once groups exist.

Refactor completion to a shared check:
- eligible standalone question remains OR
- eligible group remains.

Complete the PracticeSession only when neither remains.

Both standalone `answer()` and group `answer_group()` must use the same completion rule.

## 11. API

Add the new next-item and group-answer routes while keeping existing APIs backward
compatible.

No public QuestionGroup approval endpoint in this phase.
No visual asset serving in this phase.

## 12. Required tests

Add migration/model/service/API tests covering at minimum:

1. migration revision/down_revision and downgrade/re-upgrade;
2. DB constraints for both new tables;
3. APPROVED synthetic TRUE_FALSE_FOUR is returned as one PracticeQuestionGroupRead;
4. pre-submit response contains four ordered statements but no correct answers;
5. DRAFT group is never served;
6. group with a DRAFT child is never served;
7. missing child taxonomy makes group ineligible;
8. exact labels a,b,c,d required in submission;
9. grouped child submitted through legacy standalone `/answer` is rejected;
10. 4/4 correct => group score 1.0;
11. 3/4 => 0.5;
12. 2/4 => 0.25;
13. 1/4 => 0.1;
14. 0/4 => 0.0;
15. one group submission creates exactly 1 parent attempt + 4 child QuestionAttempts + 4 link rows;
16. child attempt numbers are consecutive and correspond to a,b,c,d;
17. evidence publisher receives exactly four events, never five;
18. each event references the correct child taxonomy;
19. real MasteryAttemptEvidencePublisher updates child-linked mastery rows;
20. static ConceptRelation row count/content does not change;
21. evidence failure on child 3 rolls back parent, all four child attempts, links and mastery changes;
22. duplicate/concurrent group submission returns stable 409 and no duplicate rows;
23. non-owner cannot fetch/submit group;
24. session remains ACTIVE while either a standalone question or group remains;
25. session completes only when both pools are exhausted;
26. next-item returns group first, then standalone;
27. every listed automated selector excludes grouped children even when child status is APPROVED;
28. staff/admin Question Bank can still inspect child rows;
29. current derivative imported data remains DRAFT and is not served;
30. upstream invariants remain 67/67 review, 38/152 canonical snapshot, 8/1 visuals, production eligible 0;
31. raw candidate SHA remains `b627a458e0b18c0a4e0733e18864e0bd83165f94894a7d690e4fc1313f3ed4d5`.

Also run all existing practice, mastery, diagnostics, repair, recommendation, assignment and
exam selector regression tests affected by the shared eligibility helper.

## 13. Explicitly deferred

Do not implement yet:
- teacher Assignment -> QuestionAttempt/mastery bridge;
- QuestionGroup assignments;
- rights clearance;
- group approval/publishing workflow;
- visual asset delivery;
- automatic KnowledgeGap -> remediation loop.

Suggested commit message:

`feat: add group-aware true-false practice`

Return:
- changed files
- migration result
- group scoring test matrix
- child-isolation audit results
- pytest summary
- new commit SHA
