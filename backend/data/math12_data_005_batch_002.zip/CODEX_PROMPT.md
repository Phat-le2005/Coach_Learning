Implement DATA-MATH12-005 review batch 002 in Phat-le2005/Coach_Learning.

BASE COMMIT
The current latest commit is a5edd811b18995cbae6235962b9e1b1374ddef4d.

Use the supplied batch files exactly. Do not invent, rewrite, or reclassify academic content beyond the review data.

FIRST FIX THE EXISTING REVIEW REPORTING ISSUE
The current QuestionStagingValidator validates batch_001 but still computes coverage/promotion from the raw 175 candidates.

Implement explicit dual views:

1. RAW STAGING VIEW
- candidate_questions.json remains immutable.
- raw count remains 175.
- raw coverage remains available for audit.

2. EFFECTIVE REVIEWED VIEW
- apply valid review batches in lexical order: batch_001, batch_002, ...
- overlays must be composed sequentially on an in-memory copy.
- a candidate ID may be reviewed by at most one batch unless a future supersede mechanism is explicitly designed.
- REJECTED candidates are excluded from effective usable coverage.
- HOLD candidates remain visible separately but are not promotable.
- VERIFIED with promotion_ready=false has EXPLICIT_PROMOTION_REQUIRED.

Remove the accidental archive if it still exists:
backend/data/math12_data_005_verified_question_review_v0_1.zip

ADD BATCH 002
Copy:
backend/data/questions/math/grade12/derivative_applications_v0_1/review/batch_002/

Expected batch_002 counts:
- reviewed: 39
- VERIFIED: 13
- HOLD: 8
- REJECTED: 18
  - duplicate: 12
  - out-of-scope: 6

Expected cumulative state after batch_001 + batch_002:
- raw candidates: 175
- reviewed: 55
- VERIFIED: 25
- HOLD: 10
- REJECTED: 20
- untouched REVIEW_REQUIRED: 120

REVIEW RULES
1. Preserve raw candidate_questions.json byte-for-byte.
2. Preserve source_code, subsource_code, source_page, question_number, original fingerprint, raw text and detected type.
3. Do not auto-promote any VERIFIED candidate.
4. All new VERIFIED candidates have promotion_ready=false.
5. All 13 batch_002 VERIFIED questions have visual_asset_required=true.
6. A visual-dependent candidate must remain blocked from production until a separate visual asset/promotion workflow is implemented.
7. HOLD_PRIMARY_SOURCE_CROSSCHECK remains REVIEW_REQUIRED.
8. HOLD_QUESTION_TYPE_CORRECTION remains REVIEW_REQUIRED and requires TRUE_FALSE_GROUP/QuestionGroup handling.
9. REJECTED_DUPLICATE and REJECTED_OUT_OF_SCOPE must never be promotable.
10. For REJECTED_DUPLICATE, validate duplicate_of_candidate_id exists.
11. Do not change mastery, recommendation, digital twin, diagnostics, attempts, or canonical curriculum.
12. No migrations.

IMPORTANT IDS
Primary-source HOLD:
- M12_DERIV_CAND_0003
- M12_DERIV_CAND_0007
- M12_DERIV_CAND_0009

Question-type HOLD:
- M12_DERIV_CAND_0012
- M12_DERIV_CAND_0019
- M12_DERIV_CAND_0035
- M12_DERIV_CAND_0047
- M12_DERIV_CAND_0052

Out-of-scope:
- M12_DERIV_CAND_0048
- M12_DERIV_CAND_0080
- M12_DERIV_CAND_0151
- M12_DERIV_CAND_0166
- M12_DERIV_CAND_0168
- M12_DERIV_CAND_0171

TESTS
Add/update tests proving:
- batch_001 remains valid;
- batch_002 is valid;
- raw candidate count remains 175;
- raw file hash/content is unchanged after overlay resolution;
- effective cumulative counts are exactly 25 VERIFIED / 10 HOLD / 20 REJECTED / 120 untouched;
- effective reviewed total is 55;
- all 25 VERIFIED still have promotion blockers;
- 13 batch_002 VERIFIED candidates include VISUAL_ASSET_REQUIRED (or equivalent blocker) in addition to EXPLICIT_PROMOTION_REQUIRED;
- rejected candidates are excluded from effective usable coverage;
- duplicate targets resolve;
- the five misdetected a/b/c/d candidates remain blocked as TRUE_FALSE_GROUP-required;
- primary-source HOLD candidates remain blocked;
- batch IDs do not overlap;
- current TRUE_FALSE_GROUP production guard stays unchanged.

Run:
cd backend
pytest
python -m app.validate_curriculum_staging
python -m app.validate_question_staging

Report exact commands, exact pass/fail counts, and changed files.
Do not claim tests passed unless they actually ran.
